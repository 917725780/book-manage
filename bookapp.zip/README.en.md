# bookManage

#### Description
angular + springboot + mysql + docker-compose crud demo.

#### Software Architecture
Single page + micro services.

#### Installation
a: build spring boot application
cd bookapp
mvn clean package -DskipTests
cp  .\target\bookapp-0.0.1.jar ..\docker-compose\apps\java\bookapp.jar

b: bould app images and run
1 cd docker-compose
2 docker-compose up
3 access localhost with chrome.
4 make sure your ports 80 8080 3306 are available.


#### Instructions

1.  xxxx
2.  xxxx
3.  xxxx

#### Contribution

1.  Fork the repository
2.  Create Feat_xxx branch
3.  Commit your code
4.  Create Pull Request


#### Gitee Feature

1.  You can use Readme\_XXX.md to support different languages, such as Readme\_en.md, Readme\_zh.md
2.  Gitee blog [blog.gitee.com](https://blog.gitee.com)
3.  Explore open source project [https://gitee.com/explore](https://gitee.com/explore)
4.  The most valuable open source project [GVP](https://gitee.com/gvp)
5.  The manual of Gitee [https://gitee.com/help](https://gitee.com/help)
6.  The most popular members  [https://gitee.com/gitee-stars/](https://gitee.com/gitee-stars/)
