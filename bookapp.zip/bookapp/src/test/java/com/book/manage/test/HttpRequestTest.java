package com.book.manage.test;


import org.junit.jupiter.api.Test;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.boot.test.web.client.TestRestTemplate;

import com.book.manage.Book;

import static org.assertj.core.api.Assertions.assertThat;

@SpringBootTest(webEnvironment = WebEnvironment.DEFINED_PORT)
class HttpRequestTest {

	
	private int port=9080;

	@Autowired
	private TestRestTemplate restTemplate;

	@Test
	void retrieveShouldReturnBook() throws Exception {
		assertThat(this.restTemplate.getForObject("http://localhost:" + port + "/book/retrieve?id=1",
				Book.class)).isNotNull();
	}
	@Test
	void deleteShouldReturnDelete() throws Exception {
		assertThat(this.restTemplate.getForObject("http://localhost:" + port + "/book/delete?id=2",
				String.class)).contains("deleted");
	}
	@Test
	void searchShouldReturnIterable() throws Exception {
		assertThat(this.restTemplate.getForObject("http://localhost:" + port + "/book/search?title=go programming",
		Iterable.class)).isNotNull();
	}
	@Test
	void allShouldReturnIterable() throws Exception {
		assertThat(this.restTemplate.getForObject("http://localhost:" + port + "/book/all",
		Iterable.class)).isNotNull();
	}
	@Test
	void putShouldReturnBook() throws Exception {
		Book book= new Book();
		book.setAuthor("Tom");
		book.setTitle("rust programming");
		book.setIsbn("rustisbn");
		book.setYear(2018);
		assertThat(this.restTemplate.postForObject("http://localhost:" + port + "/book/all",book,
		Book.class)).isNotNull();
	}
	@Test
	void updateShouldReturnBook() throws Exception {
		Book book= new Book();
		book.setId(2);
		book.setAuthor("Tom");
		book.setTitle("rust programming");
		book.setIsbn("rustisbn");
		book.setYear(2018);
		assertThat(this.restTemplate.postForObject("http://localhost:" + port + "/book/all",book,
		Book.class)).isNotNull();
	}
}

