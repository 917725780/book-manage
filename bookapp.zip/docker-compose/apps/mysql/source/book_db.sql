create database if not exists book_db;
use book_db;

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for book
-- ----------------------------
DROP TABLE IF EXISTS `book`;
CREATE TABLE `book`
(
    `id`     INT AUTO_INCREMENT PRIMARY KEY,
    `title`   VARCHAR(100) NOT NULL COMMENT 'book title',
    `isbn` VARCHAR(100) NOT NULL COMMENT 'book isbn',
    `author`   VARCHAR(100) NOT NULL COMMENT 'book author',
    `year`   INT NOT NULL COMMENT 'publicaton year',
    CONSTRAINT book_isbn_uindex UNIQUE (isbn)
) ENGINE = InnoDB
  CHARACTER SET = utf8mb4 COMMENT 'book'
  ROW_FORMAT = Dynamic;
CREATE INDEX idx_book_name ON book (title);
-- 初始化books
INSERT INTO `book`(`id`, `title`, `isbn`,`author`,`year`) VALUES (27, 'thinking in java', 'javaisbn', 'John',2008);
INSERT INTO `book`(`id`, `title`, `isbn`,`author`,`year`) VALUES (28, 'cpp programming', 'cppisbn', 'Jerry',2011);
INSERT INTO `book`(`id`, `title`, `isbn`,`author`,`year`) VALUES (29, 'python ai', 'pythonisbn', 'Tom',2019);
CREATE USER 'bookconn'@'%' IDENTIFIED BY 'connpassword';
GRANT SELECT, INSERT, UPDATE, DELETE, CREATE, ALTER ON book_db.* TO 'bookconn'@'%';
