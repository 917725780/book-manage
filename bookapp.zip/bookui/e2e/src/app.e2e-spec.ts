import { browser, element, by, ElementFinder, ElementArrayFinder } from 'protractor';

const expectedH1 = '藏经阁';
const expectedTitle = `${expectedH1}`;
const targetBook = { id: 27, title: 'thinking in java' };
const targetBookDashboardIndex = 1;
const titleSuffix = 'X';
const newBookTitle = targetBook.title + titleSuffix;

class Book {
  constructor(public id: number, public title: string) {}

  // Factory methods

  // Book from string formatted as '<id> <title>'.
  static fromString(s: string): Book {
    return new Book(
      +s.substring(0, s.indexOf(' ')),
      s.slice(s.indexOf(' ') + 1),
    );
  }

  // Book from book list <li> element.
  static async fromLi(li: ElementFinder): Promise<Book> {
    const stringsFromA = await li.all(by.css('a')).getText();
    const strings = stringsFromA[0].split(' ');
    return { id: +strings[0], title: strings[1] };
  }

  // book id and title from the given detail element.
  static async fromDetail(detail: ElementFinder): Promise<Book> {
    // Get book id from the first <div>
    const id = await detail.all(by.css('div')).first().getText();
    // Get title from the h2
    const title = await detail.element(by.css('h2')).getText();
    return {
      id: +id.slice(id.indexOf(' ') + 1),
      title: title.substring(0, title.lastIndexOf(' '))
    };
  }
}

describe('book manage', () => {

  beforeAll(() => browser.get(''));

  function getPageElts() {
    const navElts = element.all(by.css('app-root nav a'));

    return {
      navElts,

      appDashboardHref: navElts.get(0),
      appDashboard: element(by.css('app-root app-dashboard')),
      topBooks: element.all(by.css('app-root app-dashboard > div a')),

      appBooksHref: navElts.get(1),
      appBooks: element(by.css('app-root app-books')),
      allBooks: element.all(by.css('app-root app-books li')),
      selectedBookSubview: element(by.css('app-root app-books > div:last-child')),

      bookDetail: element(by.css('app-root app-book-detail > div')),

      searchBox: element(by.css('#search-box')),
      searchResults: element.all(by.css('.search-result li'))
    };
  }

  describe('Initial page', () => {

    it(`has title '${expectedTitle}'`, async () => {
      expect(await browser.getTitle()).toEqual(expectedTitle);
    });

    it(`has h1 '${expectedH1}'`, async () => {
      await expectHeading(1, expectedH1);
    });

    const expectedViewNames = ['Dashboard', 'Books'];
    it(`has views ${expectedViewNames}`, async () => {
      const viewNames = await getPageElts().navElts.map(el => el!.getText());
      expect(viewNames).toEqual(expectedViewNames);
    });

    it('has dashboard as the active view', async () => {
      const page = getPageElts();
      expect(await page.appDashboard.isPresent()).toBeTruthy();
    });

  });

  describe('Dashboard tests', () => {

    beforeAll(() => browser.get(''));

    it('has top books', async () => {
      const page = getPageElts();
      expect(await page.topBooks.count()).toEqual(3);
    });

    it(`selects and routes to ${targetBook.title} details`, dashboardSelectTargetBook);

    it(`updates book title (${newBookTitle}) in details view`, updateBookTitleInDetailView);

    it(`cancels and shows ${targetBook.title} in Dashboard`, async () => {
      await element(by.buttonText('go back')).click();
      await browser.waitForAngular(); // seems necessary to gets tests to pass

      const targetBookElt = getPageElts().topBooks.get(targetBookDashboardIndex);
      expect(await targetBookElt.getText()).toEqual(targetBook.title);
    });

    it(`selects and routes to ${targetBook.title} details`, dashboardSelectTargetBook);

    it(`updates book title (${newBookTitle}) in details view`, updateBookTitleInDetailView);

    it(`saves and shows ${newBookTitle} in Dashboard`, async () => {
      await element(by.buttonText('save')).click();
      await browser.waitForAngular(); // seems necessary to gets tests to pass

      const targetBookElt = getPageElts().topBooks.get(targetBookDashboardIndex);
      expect(await targetBookElt.getText()).toEqual(newBookTitle);
    });

  });

  describe('Books tests', () => {

    beforeAll(() => browser.get(''));

    it('can switch to Books view', async () => {
      await getPageElts().appBooksHref.click();
      const page = getPageElts();
      expect(await page.appBooks.isPresent()).toBeTruthy();
      expect(await page.allBooks.count()).toEqual(4, 'number of books');
    });

    it('can route to book details', async () => {
      await getBookLiEltById(targetBook.id).click();

      const page = getPageElts();
      expect(await page.bookDetail.isPresent()).toBeTruthy('shows hero detail');
      const book = await Book.fromDetail(page.bookDetail);
      expect(book.id).toEqual(targetBook.id);
      expect(book.title).toEqual(targetBook.title.toUpperCase());
    });

    it(`updates book title (${newBookTitle}) in details view`, updateBookTitleInDetailView);

    it(`shows ${newBookTitle} in Books list`, async () => {
      await element(by.buttonText('save')).click();
      await browser.waitForAngular();
      const expectedText = `${targetBook.id} ${newBookTitle}`;
      expect(await getBookAEltById(targetBook.id).getText()).toEqual(expectedText);
    });

    it(`deletes ${newBookTitle} from Books list`, async () => {
      const booksBefore = await toBookArray(getPageElts().allBooks);
      const li = getBookLiEltById(targetBook.id);
      await li.element(by.buttonText('x')).click();

      const page = getPageElts();
      expect(await page.appBooks.isPresent()).toBeTruthy();
      expect(await page.allBooks.count()).toEqual(3, 'number of books');
      const booksAfter = await toBookArray(page.allBooks);
      // console.log(await Book.fromLi(page.allBooks[0]));
      const expectedBooks =  booksBefore.filter(b => b.title !== newBookTitle);
      expect(booksAfter).toEqual(expectedBooks);
      // expect(page.selectedBookSubview.isPresent()).toBeFalsy();
    });

    it(`adds back ${targetBook.title}`, async () => {
      const addedBookTitle = 'thinking in java';
      const booksBefore = await toBookArray(getPageElts().allBooks);
      const numBooks = booksBefore.length;

      await element(by.css('input')).sendKeys(addedBookTitle);
      await element(by.buttonText('Add book')).click();

      const page = getPageElts();
      const booksAfter = await toBookArray(page.allBooks);
      expect(booksAfter.length).toEqual(numBooks + 1, 'number of books');

      expect(booksAfter.slice(0, numBooks)).toEqual(booksBefore, 'Old books are still there');

      const maxId = booksBefore[booksBefore.length - 1].id;
      expect(booksAfter[numBooks]).toEqual({id: maxId + 1, title: addedBookTitle});
    });

    it('displays correctly styled buttons', async () => {
      const buttons = await element.all(by.buttonText('x'));

      for (const button of buttons) {
        // Inherited styles from styles.css
        expect(await button.getCssValue('font-family')).toBe('Arial, Helvetica, sans-serif');
        expect(await button.getCssValue('border')).toContain('none');
        expect(await button.getCssValue('padding')).toBe('1px 10px 3px');
        expect(await button.getCssValue('border-radius')).toBe('4px');
        // Styles defined in books.component.css
        expect(await button.getCssValue('left')).toBe('210px');
        expect(await button.getCssValue('top')).toBe('5px');
      }

      const addButton = element(by.buttonText('Add book'));
      // Inherited styles from styles.css
      expect(await addButton.getCssValue('font-family')).toBe('Arial, Helvetica, sans-serif');
      expect(await addButton.getCssValue('border')).toContain('none');
      expect(await addButton.getCssValue('padding')).toBe('8px 24px');
      expect(await addButton.getCssValue('border-radius')).toBe('4px');
    });

  });

  describe('Progressive book search', () => {

    beforeAll(() => browser.get(''));

    it(`searches for 'thinking in java'`, async () => {
      await getPageElts().searchBox.sendKeys('thinking in java');
      await browser.sleep(1000);

      expect(await getPageElts().searchResults.count()).toBe(1);
    });

    it(`continues search with 'go programming'`, async () => {
      await getPageElts().searchBox.sendKeys('go programming');
      await browser.sleep(1000);
      expect(await getPageElts().searchResults.count()).toBe(1);
    });

    it(`continues search with 'cpp programming' and gets cpp programming`, async () => {
      await getPageElts().searchBox.sendKeys('cpp programming');
      await browser.sleep(1000);
      const page = getPageElts();
      expect(await page.searchResults.count()).toBe(1);
      const book = page.searchResults.get(0);
      expect(await book.getText()).toEqual('cpp programming');
    });

    it(`navigates to ${targetBook.title} details view`, async () => {
      const book = getPageElts().searchResults.get(0);
      expect(await book.getText()).toEqual(targetBook.title);
      await book.click();

      const page = getPageElts();
      expect(await page.bookDetail.isPresent()).toBeTruthy('shows book detail');
      const book2 = await Book.fromDetail(page.bookDetail);
      expect(book2.id).toEqual(targetBook.id);
      expect(book2.title).toEqual(targetBook.title.toUpperCase());
    });
  });

  async function dashboardSelectTargetBook() {
    const targetBookElt = getPageElts().topBooks.get(targetBookDashboardIndex);
    expect(await targetBookElt.getText()).toEqual(targetBook.title);
    await targetBookElt.click();
    await browser.waitForAngular(); // seems necessary to gets tests to pass for toh-pt6

    const page = getPageElts();
    expect(await page.bookDetail.isPresent()).toBeTruthy('shows book detail');
    const book = await Book.fromDetail(page.bookDetail);
    expect(book.id).toEqual(targetBook.id);
    expect(book.title).toEqual(targetBook.title.toUpperCase());
  }

  async function updateBookTitleInDetailView() {
    // Assumes that the current view is the hero details view.
    await addToBookTitle(titleSuffix);

    const page = getPageElts();
    const book = await Book.fromDetail(page.bookDetail);
    expect(book.id).toEqual(targetBook.id);
    expect(book.title).toEqual(newBookTitle.toUpperCase());
  }

});

async function addToBookTitle(text: string): Promise<void> {
  const input = element(by.css('input'));
  await input.sendKeys(text);
}

async function expectHeading(hLevel: number, expectedText: string): Promise<void> {
  const hTag = `h${hLevel}`;
  const hText = await element(by.css(hTag)).getText();
  expect(hText).toEqual(expectedText, hTag);
}

function getBookAEltById(id: number): ElementFinder {
  const spanForId = element(by.cssContainingText('li span.badge', id.toString()));
  return spanForId.element(by.xpath('..'));
}

function getBookLiEltById(id: number): ElementFinder {
  const spanForId = element(by.cssContainingText('li span.badge', id.toString()));
  return spanForId.element(by.xpath('../..'));
}

async function toBookArray(allBooks: ElementArrayFinder): Promise<Book[]> {
  return allBooks.map(book => Book.fromLi(book!));
}
