import { Book } from './book';

export const books: Book[] = [
  {
      "id": 27,
      "title": "thinking in java",
      "isbn": "javaisbn",
      "author": "John",
      "year": 2008
  },
  {
      "id": 28,
      "title": "cpp programming",
      "isbn": "cppisbn",
      "author": "Jerry",
      "year": 2011
  },
  {
      "id": 29,
      "title": "python ai",
      "isbn": "pythonisbn",
      "author": "Tom",
      "year": 2019
  }
];
