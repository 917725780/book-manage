import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

import { Observable, of } from 'rxjs';
import { catchError, map, tap } from 'rxjs/operators';

import { Book } from './book';
import { MessageService } from './message.service';


@Injectable({ providedIn: 'root' })
export class BookService {

  private bookUrl = 'http://localhost:8080/book/';  // URL to web api
  // private bookUrl = '/api/book/';  // URL to web api

  httpOptions = {
    headers: new HttpHeaders({ 'Content-Type': 'application/json' })
  };

  constructor(
    private http: HttpClient,
    private messageService: MessageService) { }

  /** GET Bookes from the server */
  getBooks(): Observable<Book[]> {
    return this.http.get<Book[]>(this.bookUrl+'all')
      .pipe(
        tap(_ => this.log('fetched books')),
        catchError(this.handleError<Book[]>('getBookes', []))
      );
  }

  /** GET Book by id. Return `undefined` when id not found */
  getBookNo404<Data>(id: number): Observable<Book> {
    const url = `${this.bookUrl}retrieve?id=${id}`;
    return this.http.get<Book>(url)
      .pipe(
        map(book => book), // returns a {0|1} element array
        tap(h => {
          const outcome = h ? 'fetched' : 'did not find';
          this.log(`${outcome} book id=${id}`);
        }),
        catchError(this.handleError<Book>(`getBook id=${id}`))
      );
  }

  /** GET Book by id. Will 404 if id not found */
  getBook(id: number): Observable<Book> {
    const url = `${this.bookUrl}retrieve?id=${id}`;
    return this.http.get<Book>(url).pipe(
      tap(_ => this.log(`fetched book id=${id}`)),
      catchError(this.handleError<Book>(`getBook id=${id}`))
    );
  }

  /* GET Bookes whose name contains search name */
  searchBooks(title: string): Observable<Book[]> {
    if (!title.trim()) {
      // if not search term, return empty Book array.
      return of([]);
    }
    return this.http.get<Book[]>(`${this.bookUrl}search?title=${title}`).pipe(
      tap(x => x.length ?
         this.log(`found Bookes matching "${title}"`) :
         this.log(`no Bookes matching "${title}"`)),
      catchError(this.handleError<Book[]>('searchBookes', []))
    );
  }

  //////// Save methods //////////

  /** POST: add a new Book to the server */
  addBook(book: Book): Observable<Book> {
    return this.http.post<Book>(this.bookUrl+'add', book, this.httpOptions).pipe(
      tap((book: Book) => this.log(`added Book w/ ${JSON.stringify(book)}`)),
      catchError(this.handleError<Book>('addBook ${JSON.stringify(book)'))
    );
  }

  /** DELETE: delete the Book from the server */
  deleteBook(id: number): Observable<string> {
    const url = `${this.bookUrl}delete?id=${id}`;

    return this.http.get<string>(url).pipe(
      tap(_ => this.log(`deleted Book id=${id}`)),
      catchError(this.handleError<string>('deleteBook'))
    );
  }

  /** PUT: update the Book on the server */
  updateBook(book: Book): Observable<Book> {
    return this.http.post<Book>(this.bookUrl+'update', book, this.httpOptions).pipe(
      tap(_ => this.log(`updated Book id=${book.id}`)),
      catchError(this.handleError<Book>(`updateBook ${JSON.stringify(book)}`))
    );
  }

  /**
   * Handle Http operation that failed.
   * Let the app continue.
   *
   * @param operation - name of the operation that failed
   * @param result - optional value to return as the observable result
   */
  private handleError<T>(operation = 'operation', result?: T) {
    return (error: any): Observable<T> => {

      // TODO: send the error to remote logging infrastructure
      console.error(error); // log to console instead

      // TODO: better job of transforming error for user consumption
      this.log(`${operation} failed: ${error.message}`);

      // Let the app keep running by returning an empty result.
      return of(result as T);
    };
  }

  /** Log a BookService message with the MessageService */
  private log(message: string) {
    this.messageService.add(`BookService: ${message}`);
  }
}
