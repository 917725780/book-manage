import { Component, OnInit } from '@angular/core';

import { Observable, Subject } from 'rxjs';

import {
   debounceTime, distinctUntilChanged, switchMap
 } from 'rxjs/operators';

import { Book } from '../book';
import { BookService } from '../book.service';

@Component({
  selector: 'app-book-search',
  templateUrl: './book-search.component.html',
  styleUrls: [ './book-search.component.css' ]
})
export class BookSearchComponent implements OnInit {
  books$!: Observable<Book[]>;
  private searchName = new Subject<string>();

  constructor(private bookService: BookService) {}

  // Push a search term into the observable stream.
  search(title: string): void {
    console.log("this.searchName.next(title)",title)
    this.searchName.next(title);
  }

  ngOnInit(): void {
    this.books$ = this.searchName.pipe(
      // wait 300ms after each keystroke before considering the term
      debounceTime(300),

      // ignore new term if same as previous term
      distinctUntilChanged(),

      // switch to new search observable each time the term changes
      switchMap((title: string) => this.bookService.searchBooks(title)),
    );
    console.log("this.books$ = this.searchName.pipe"+this.books$.subscribe({next:(books)=>{console.log(JSON.stringify(books))}}))
  }
}
