import {ComponentFixture, TestBed, waitForAsync, fakeAsync, tick} from '@angular/core/testing';
import {RouterModule} from '@angular/router';
import {of} from 'rxjs';

import {BookSearchComponent} from '../book-search/book-search.component';
import {BookService} from '../book.service';
import {books} from '../mock-books';

import {DashboardComponent} from './dashboard.component';

describe('DashboardComponent', () => {
  let component: DashboardComponent;
  let fixture: ComponentFixture<DashboardComponent>;
  let bookService;
  let input: any;
  let getBooksSpy: jasmine.Spy;
  let searchBooksSpy: jasmine.Spy;

  beforeEach(waitForAsync(() => {
    bookService = jasmine.createSpyObj('BookService', ['getBooks','searchBooks']);
    getBooksSpy = bookService.getBooks.and.returnValue(of(books));
    searchBooksSpy = bookService.searchBooks.and.returnValue(of(books.slice(1,2)));
    TestBed
        .configureTestingModule({
          declarations: [DashboardComponent, BookSearchComponent],
          imports: [RouterModule.forRoot([])],
          providers: [
            {provide: BookService, useValue: bookService},
          ]
        })
        .compileComponents();

    fixture = TestBed.createComponent(DashboardComponent);
    input = fixture.nativeElement.querySelector("#search-box");
    input.value = 'thinking in java';
    input.dispatchEvent(new Event('input'));
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should be created', () => {
    expect(component).toBeTruthy();
  });

  it('should display "Top books" as headline', () => {
    expect(fixture.nativeElement.querySelector('h2').textContent).toEqual('Top books');
  });

  it('should call bookService', waitForAsync(() => {
       expect(getBooksSpy.calls.any()).toBe(true);
     }));

  it('should display 2 links', waitForAsync(() => {
       expect(fixture.nativeElement.querySelectorAll('a').length).toEqual(2);
     }));
  it('should emit input event when the input value set', fakeAsync(() => {
    input.value = 'thinking in java';
    input.dispatchEvent(new Event('input'));
    fixture.detectChanges();
    tick(1000);
    expect(searchBooksSpy.calls.any()).toBe(true);
    }));
});
