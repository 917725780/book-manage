import {ComponentFixture, TestBed, waitForAsync} from '@angular/core/testing';
import {RouterModule} from '@angular/router';
import {of} from 'rxjs';
import {ActivatedRoute } from '@angular/router';
import {BookService} from '../book.service';
import {books} from '../mock-books';

import {BookDetailComponent} from './book-detail.component';
import { ActivatedRouterStub } from '../activated.router.stub';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
describe('BookDetailComponent', () => {
  let component: BookDetailComponent;
  let fixture: ComponentFixture<BookDetailComponent>;
  let bookService;
  let router: ActivatedRoute;
  let route: ActivatedRouterStub;
  let getbookSpy: jasmine.Spy;

  beforeEach(waitForAsync(() => {
    bookService = jasmine.createSpyObj('BookService', ['getBook']);
    getbookSpy = bookService.getBook.and.returnValue(of(books[0]));
    route = new ActivatedRouterStub();
    TestBed
        .configureTestingModule({
          declarations: [BookDetailComponent],
          imports: [RouterModule.forRoot([]),FormsModule],
          providers: [
            {provide: BookService, useValue: bookService},
            {provide: ActivatedRoute, useValue: route}
          ]
        })
        .compileComponents();
        route.setParamMap({id: 1}); 
    fixture = TestBed.createComponent(BookDetailComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));
  it('should get activatedRoute params', () => {
    router = fixture.debugElement.injector.get(ActivatedRoute);
    component.ngOnInit();
    expect(component.book?.id).toBe(27);
});
  it('should be created', () => {
    expect(component).toBeTruthy();
  });

  it('should display "THINKING IN JAVA Details" as headline', () => {
    expect(fixture.nativeElement.querySelector('h2').textContent).toEqual('THINKING IN JAVA Details');
  });

  it('should call bookService', waitForAsync(() => {
       expect(getbookSpy.calls.any()).toBe(true);
     }));

  it('should display 3 book properties', waitForAsync(() => {
       expect(fixture.nativeElement.querySelectorAll('label').length).toEqual(4);
     }));
});
