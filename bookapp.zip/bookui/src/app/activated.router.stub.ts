import {convertToParamMap, ParamMap, Params} from '@angular/router';


export class ActivatedRouterStub {
  snapshot=this;


  constructor(initialParams?: Params) {
    if (!initialParams){
      initialParams={id:1}
    }
    this.setParamMap(initialParams);
  }

  /** The mock paramMap observable */
  paramMap: ParamMap = convertToParamMap({id:1})

  /** Set the paramMap observables's next value */
  setParamMap(params: Params) {
    this.paramMap=convertToParamMap(params)
  }
}