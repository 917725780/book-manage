import {ComponentFixture, TestBed, waitForAsync} from '@angular/core/testing';
import {RouterModule} from '@angular/router';
import {of} from 'rxjs';

import {BookService} from '../book.service';
import {books} from '../mock-books';

import {BooksComponent} from './books.component';

describe('BooksComponent', () => {
  let component: BooksComponent;
  let fixture: ComponentFixture<BooksComponent>;
  let bookService;
  let getbooksSpy: jasmine.Spy;

  beforeEach(waitForAsync(() => {
    bookService = jasmine.createSpyObj('BookService', ['getBooks']);
    getbooksSpy = bookService.getBooks.and.returnValue(of(books));
    TestBed
        .configureTestingModule({
          declarations: [BooksComponent],
          imports: [RouterModule.forRoot([])],
          providers: [
            {provide: BookService, useValue: bookService},
          ]
        })
        .compileComponents();
    
    fixture = TestBed.createComponent(BooksComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should be created', () => {
    expect(component).toBeTruthy();
  });

  it('should display "My books" as headline', () => {
    expect(fixture.nativeElement.querySelector('h2').textContent).toEqual('My books');
  });

  it('should call bookService', waitForAsync(() => {
       expect(getbooksSpy.calls.any()).toBe(true);
     }));

  it('should display 3 books', waitForAsync(() => {
       expect(fixture.nativeElement.querySelectorAll('li').length).toEqual(3);
     }));
});
